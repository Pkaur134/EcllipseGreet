package questionClass;
/**
 * 
 */

/**
 * @author 
 *
 */
enum QuestionType {
	
	TRUE_FALSE("TRUE/FALSE"),SHORT_ANSWER("Short Answer"),MULTIPLE_CHOICE("Multiple Choice");
	
	private String type;
	
	public String getType(){
		return type;
	}
	
	private QuestionType(String type){
		this.type = type;
	}
	

}
