package questionClass;


public class SAQuestion extends Question {

	private String answer;

	public SAQuestion(int id, String text, String answer){
		
		super(id, text);
		this.answer = answer;

	}

	public SAQuestion() {
		this.answer = "TBD";

	}

	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) throws IllegalArgumentException{
		if(answer == null || answer.length()!=0) {
			throw new IllegalArgumentException("Question text is Invalid, cannot be empty");
		}
		this.answer = answer;
	
	}
	public boolean isCorrect(Object guess) { 
		if(guess==null) {
			return false;
		}
		return guess.toString().equalsIgnoreCase(this.answer);
	}
	@Override
	public String toString() {
		return "#" + this.getQuestionId() + ": " + this.answer + ".";	

	}

}