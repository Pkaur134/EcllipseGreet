package questionClass;


public class TFQuestion extends Question {

	private boolean answer = false;

	public TFQuestion(int id, String text, boolean answer){
		
		super(id, text);
		this.answer = answer;

	}

	public TFQuestion() {
	}

	public boolean isAnswer() {
		return answer;
	}
	public void setAnswer(boolean answer) {
		this.answer = answer;
	
	}
	public boolean isCorrect(Object guess) { 
		if(guess==null) {
			return false;
		}
		if(guess.getClass.equals("String")) {
			return guess.toString.toLowerCase.equals("true")==this.answer;
		}
		if(guess.getClass.equals("Boolean")){
			return (Boolean)guess==this.answer;
		}
		return false;
	}
	@Override
	public String toString() {
		return "#" + this.getQuestionId() + ": " + this.answer + ".";	

	}

}